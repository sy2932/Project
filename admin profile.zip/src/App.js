import AdminProfile from './components/AdminProfile';
import './App.css';

function App() {
  return (
    <div>
      <AdminProfile />
    </div>
  );
}

export default App;
