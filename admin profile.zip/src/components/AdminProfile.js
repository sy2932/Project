import React, { useState } from 'react';
import './AdminProfile.css';
import dotheRightThing from './DotheRightThing.png';
import neverSettle from './NeverSettle.png';
import betterTogether from './BetterTogether.png';
import profileIcon from './Profile_Icon.png';
import scbLogo from './SCBlogo.png';

const AdminProfile = () => {
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpInput, setOtpInput] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [isSecurityOpen, setIsSecurityOpen] = useState(false);
 
  const extendedProfile = isSecurityOpen;
  const [passwords, setPasswords] = useState({
    current: '',
    new: '',
    confirm: ''
  });
  const [contactInfo, setContactInfo] = useState({
    email: 'admin@sc.com',
    phone: '9876543212'
  });

  const [profileImage, setProfileImage] = useState(null);

  const employeeData = {
    name: 'Admin User',
    employeeId: 'ADMIN001',

    role: 'System Administrator',
    email: contactInfo.email,
    phone: contactInfo.phone,
    profileImage: profileImage
  };

  const toggleEdit = () => {
    setIsEditing(!isEditing);
  };

  const toggleSecurity = () => {
    setIsSecurityOpen(!isSecurityOpen);
  };

  const handlePasswordChange = (field, value) => {
    setPasswords(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleContactChange = (field, value) => {
    setContactInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePasswordSubmit = () => {
    if (!otpVerified) {
      alert('Please verify OTP before updating password.');
      return;
    }
    if (passwords.new !== passwords.confirm) {
      alert('New passwords do not match!');
      return;
    }
    if (passwords.new.length < 6) {
      alert('Password must be at least 6 characters long!');
      return;
    }
    
    setPasswords({ current: '', new: '', confirm: '' });
  };

  const handleContactSubmit = () => {

    alert('Contact information updated successfully!');
    setIsEditing(false);
  };

  const handleClose = () => {
    if (window.confirm('Are you sure you want to close this profile?')) {
      
      alert('Profile closed');
    }
  };


  const handleProfileImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result);
        
        alert('Profile image updated successfully!');
        setIsEditing(false); 
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="admin-profile-container">
      {/* Close Button */}
      <button className="close-btn" onClick={handleClose}>
        <span>×</span>
      </button>

      <div className="profile-layout">
  
  <div className={`profile-card${extendedProfile ? ' extended-profile-card' : ''}`}> 
          <div className="profile-header">
            <div className="profile-avatar-section">
              <div className="profile-avatar">
                {isEditing ? (
                  <div className="avatar-edit-container">
                    <img 
                      src={profileImage || profileIcon} 
                      alt="Profile" 
                      className="avatar-image"
                    />
                    <div className="avatar-edit-overlay">
                      <label htmlFor="profile-image-input" className="avatar-edit-label">
                        <span>📷</span>
                      </label>
                      <input
                        id="profile-image-input"
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleProfileImageChange(e)}
                        style={{ display: 'none' }}
                      />
                    </div>
                  </div>
                ) : (
                  <img 
                    src={profileImage || profileIcon} 
                    alt="Profile" 
                    className="avatar-image"
                  />
                )}
              </div>
              <div className="profile-name">
                {employeeData.name}
                <img src={scbLogo} alt="SCB Logo" className="scb-logo" />
              </div>
            </div>
          </div>

          <div className="profile-details">
            <div className="details-box">
              <h3>Admin Details</h3>
              <div className="detail-item">
                <span>Admin Id: {employeeData.employeeId}</span>
              </div>
              <div className="detail-item">
                <span>Role: {employeeData.role}</span>
              </div>
            </div>
            {/* OTP Verification Section */}
            {isSecurityOpen && (
              <div className="otp-section" style={{ margin: '2rem 0', padding: '1.5rem', background: '#f5f5f5', borderRadius: '10px', boxShadow: '0 2px 8px rgba(0,0,0,0.07)' }}>
                <h3 style={{ marginBottom: '1rem', color: '#333' }}>OTP Verification</h3>
                <p style={{ marginBottom: '1rem', color: '#555' }}>Enter the OTP sent to your registered email or phone number to verify admin access.</p>
                <input type="text" maxLength="6" value={otpInput} onChange={e => setOtpInput(e.target.value)} placeholder="Enter OTP" style={{ padding: '0.75rem', fontSize: '1rem', borderRadius: '6px', border: '1px solid #ccc', width: '100%', marginBottom: '1rem' }} />
                <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => {
                  if (otpInput.length === 6) {
                    setOtpVerified(true);
                    alert('OTP Verified!');
                  } else {
                    alert('Please enter a valid 6-digit OTP.');
                  }
                }}>
                  Verify OTP
                </button>
              </div>
            )}
          </div>
          <div className="profile-actions">
            <div style={{ display: isSecurityOpen ? 'flex' : 'none', flexDirection: 'column', gap: '0.75rem' }}>
              <button className="btn btn-warning" onClick={() => alert('Manage Users')}>
                Manage Users
              </button>
              <button className="btn btn-primary" onClick={() => alert('Changes Saved!')}>
                Save Changes
              </button>
            </div>
          </div>
        </div>

      
  <div className="right-section">
         
          <div className="info-panel contact-panel">
            <div className="panel-header blue-header">
              <h3>Contact Details</h3>
            </div>
            <div className="panel-content open">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '1.1em' }}>Admin Mail Id: {contactInfo.email}</span>
                <span style={{ fontSize: '1.1em' }}>Admin Phone.No: {contactInfo.phone}</span>
              </div>
            </div>
          </div>

          {/* Security Controls Panel */}
          <div className="info-panel security-panel">
            <div className="panel-header green-header" onClick={toggleSecurity}>
              <h3>Security Controls</h3>
              <div className={`dropdown-arrow ${isSecurityOpen ? 'open' : ''}`}>▼</div>
            </div>
            <div className={`panel-content ${isSecurityOpen ? 'open' : ''}`}>
              <div className="password-section">
                <h4>Password Change</h4>
                <div className="password-fields">
                  <div className="field-group">
                    <label>Current Password:</label>
                    <input 
                      type="password" 
                      placeholder="Enter current password"
                      value={passwords.current}
                      onChange={(e) => handlePasswordChange('current', e.target.value)}
                    />
                  </div>
                  <div className="field-group">
                    <label>New Password:</label>
                    <input 
                      type="password" 
                      placeholder="Enter new password"
                      value={passwords.new}
                      onChange={(e) => handlePasswordChange('new', e.target.value)}
                    />
                  </div>
                  <div className="field-group">
                    <label>Re-enter New Password:</label>
                    <input 
                      type="password" 
                      placeholder="Re-enter new password"
                      value={passwords.confirm}
                      onChange={(e) => handlePasswordChange('confirm', e.target.value)}
                    />
                  </div>
                  <button className="btn btn-primary password-submit-btn" onClick={handlePasswordSubmit}>
                    Update Password
                  </button>
                </div>
              </div>
            </div>
          </div>

       
          <div className="images-section">
            <div className="image-item">
              <div className="image-placeholder">
                <img src={dotheRightThing} alt="Do the right thing" className="png-image" />
              </div>
              <div className="image-label"><strong>Do the right thing</strong></div>
            </div>
            <div className="image-item">
              <div className="image-placeholder">
                <img src={neverSettle} alt="Never settle" className="png-image" />
              </div>
              <div className="image-label"><strong>Never settle</strong></div>
            </div>
            <div className="image-item">
              <div className="image-placeholder">
                <img src={betterTogether} alt="Better together" className="png-image" />
              </div>
              <div className="image-label"><strong>Better together</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminProfile;

