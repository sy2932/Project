import React, { useState } from 'react';
import './App.css';

function App() {
  const [photo, setPhoto] = useState(null);
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    mailId: '',
    phoneNo: '',
    employeeId: '',
    role: '',
    department: ''
  });
  const [phoneWarning, setPhoneWarning] = useState('');
  const [emailWarning, setEmailWarning] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (name === 'phoneNo') {
      const phonePattern = /^[6-9][0-9]{9}$/;
      setPhoneWarning(phonePattern.test(value) ? '' : 'Enter a valid phone number');
    }
    if (name === 'mailId') {
      const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      setEmailWarning(emailPattern.test(value) ? '' : 'Enter a valid email address');
    }
  };

  const handlePhotoUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      setPhoto(URL.createObjectURL(e.target.files[0]));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Saved!');
    setForm({
      firstName: '',
      lastName: '',
      mailId: '',
      phoneNo: '',
      employeeId: '',
      role: '',
      department: ''
    });
  };

  return (
    <div className="main-bg">
      <div className="header">
        <div className="navbar-left">
          <img src={require('./logo.png')} alt="logo" className="navbar-logo-profile" />
          <span className="navbar-brand">
            <span className="navbar-brand-top">Standard</span>
            <span className="navbar-brand-bottom">Chartered</span>
          </span>
        </div>
        <img src={require('./profile.png')} alt="profile" className="navbar-profile" />
      </div>
      <form className="form-container" onSubmit={handleSubmit}>
        <div className="top-section">
          <div className="personal-details-container">
            <div className="personal-details">
              <div className="personal-title-inside">Personal Details</div>
              <div className="personal-fields">
                <div className="field-row">
                  <div className="field-group">
                    <label>First Name</label>
                    <input type="text" name="firstName" value={form.firstName} onChange={handleChange} />
                  </div>
                  <div className="field-group">
                    <label>Last Name</label>
                    <input type="text" name="lastName" value={form.lastName} onChange={handleChange} />
                  </div>
                </div>
                <div className="field-row">
                  <div className="field-group">
                    <label>Mail Id</label>
                    <input
                      type="email"
                      name="mailId"
                      value={form.mailId}
                      onChange={handleChange}
                      pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                      title="Please enter a valid email address"
                      required
                    />
                    {emailWarning && (
                      <div style={{ color: 'red', fontSize: '0.9rem', marginTop: '2px' }}>{emailWarning}</div>
                    )}
                  </div>
                  <div className="field-group">
                    <label>Phone.No</label>
                    <input
                      type="text"
                      name="phoneNo"
                      value={form.phoneNo}
                      onChange={handleChange}
                      pattern="[6-9][0-9]{9}"
                      maxLength="10"
                      title="Phone number must start with 6-9 and be exactly 10 digits"
                      required
                    />
                    {phoneWarning && (
                      <div style={{ color: 'red', fontSize: '0.9rem', marginTop: '2px' }}>{phoneWarning}</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="profile-container">
            <div className="photo-upload">
              <div className="photo-img-container">
                {photo ? (
                  <img src={photo} alt="Profile" className="photo-img large-profile" />
                ) : (
                  <img src={require('./profile.png')} alt="Default Profile" className="photo-img large-profile" />
                )}
              </div>
              <label className="upload-btn">
                Upload Photo
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhotoUpload} />
                <span className="upload-icon">&#8682;</span>
              </label>
            </div>
          </div>
        </div>
        <div className="employee-details-container">
          <div className="employee-details">
            <div className="employee-title-inside">Employee Details</div>
            <div className="employee-fields">
              <div className="field-row">
                <div className="field-group">
                  <label>Employee Id</label>
                  <input type="text" name="employeeId" value={form.employeeId} onChange={handleChange} />
                </div>
                <div className="field-group">
                  <label>Role</label>
                  <input type="text" name="role" value={form.role} onChange={handleChange} />
                </div>
                <div className="field-group">
                  <label>Department</label>
                  <select name="department" value={form.department} onChange={handleChange}>
                    <option value="">Select</option>
                    <option value="HR">HR</option>
                    <option value="IT">IT</option>
                    <option value="Finance">Finance</option>
                    <option value="Marketing">Marketing</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button className="save-btn" type="submit">Save</button>
      </form>
    </div>
  );
}

export default App;