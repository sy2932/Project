import React, { useState, useEffect } from "react";
import "./Dash.css";
function Groupicon() {
const [isOpen, setIsOpen] = useState(false);
const [selectedOption, setSelectedOption] = useState("Allow");
useEffect(() => {
const handleClickOutside = (event) => {
if (!event.target.closest(".dropdown")) {
setIsOpen(false);
}
};
window.addEventListener("click", handleClickOutside);
return () => window.removeEventListener("click", handleClickOutside);
}, []);
const handleSelect = (option) => {
setSelectedOption(option); // Change the text
setIsOpen(false); // Close the dropdown
};
return (
<div className="dropdown">
<div className="for_access" onClick={() => setIsOpen(!isOpen)}>
{selectedOption} ▼
</div>
{isOpen && (
<div className="dropdown-menu">
<div className="dropdown-item" onClick={() => handleSelect("Allow")}>
Allow
</div>
<div className="dropdown-item" onClick={() => handleSelect("Deny")}>
Deny
</div>
</div>
)}
</div>
);
}
export default Groupicon;