import React, { useState } from "react";
import {
Form,
Button,
Dropdown,
Navbar,
Table
} from "react-bootstrap";
import {
FaTrash,
FaSearch,
FaBell,
FaUser,
FaThLarge,
FaFileAlt,
FaStar,
FaEye,
FaDownload
} from "react-icons/fa";
import "./Dash.css";
const empData = [
{ id: 1, title: "Report File 1", type: "PDF", date: "17/08/2025", size: "2.2MB" },
{ id: 2, title: "Report File 2", type: "CSV", date: "16/08/2025", size: "1.5MB" },
{ id: 3, title: "Report File 3", type: "PDF", date: "15/08/2025", size: "3.1MB" },
{ id: 4, title: "Invoice File", type: "XLSX", date: "14/08/2024", size: "4.5MB" },
{ id: 5, title: "Analysis File", type: "CSV", date: "13/08/2023", size: "2.9MB" },
{ id: 6, title: "Summary Report", type: "PDF", date: "11/07/2023", size: "3.8MB" },
{ id: 7, title: "Financial Data", type: "XLSX", date: "21/05/2022", size: "5.4MB" },
{ id: 8, title: "Market Insights", type: "CSV", date: "01/01/2024", size: "2.1MB" },
{ id: 9, title: "Sales Report", type: "PDF", date: "25/12/2023", size: "3.6MB" },
{ id: 10, title: "Budget File", type: "XLSX", date: "02/03/2022", size: "4.8MB" },
];
function Dash() {
const [selectedRows, setSelectedRows] = useState([]);
const [emp, setEmp] = useState(empData);
const [query, setQuery] = useState("");
const [filterType, setFilterType] = useState("");
const [filterYear, setFilterYear] = useState("");
const handleSelectAll = (e) => {
if (e.target.checked) {
setSelectedRows(emp.map((i) => i.id));
} else {
setSelectedRows([]);
}
};
const handleSelectRow = (id) => {
if (selectedRows.includes(id)) {
setSelectedRows(selectedRows.filter((rowId) => rowId !== id));
} else {
setSelectedRows([...selectedRows, id]);
}
};
const removeUser = (id) => {
setEmp(emp.filter((i) => i.id !== id));
setSelectedRows(selectedRows.filter((rowId) => rowId !== id));
};
const isSelectAll = selectedRows.length === emp.length;
// Filtering
const filteredData = emp.filter((i) => {
const search = query.toLowerCase();
const matchesSearch =
i.title.toLowerCase().includes(search) ||
i.type.toLowerCase().includes(search) ||
i.date.toLowerCase().includes(search);
const matchesType = filterType ? i.type === filterType : true;
const year = i.date.split("/")[2]; // Extract year from DD/MM/YYYY
const matchesYear = filterYear ? year === filterYear : true;
return matchesSearch && matchesType && matchesYear;
});
return (
<div className="dashboard-container">
{/* Navbar */}
<Navbar className="navbar shadow-sm">
<div className="navbar-container">
<Navbar.Brand href="#">
<img
src="https://upload.wikimedia.org/wikipedia/commons/0/0c/Standard_Chartered_(2021).svg"
alt="logo"
height={40}
className=" img me-3"
/>
</Navbar.Brand>
<div className="navbar-icons">
<FaBell size={30} />
<FaUser size={30} />
</div>
</div>
</Navbar>
{/* Main content */}
<div className="main-content">
{/* Sidebar */}
<div className="sidebar">
<div className="icon-wrapper">
<FaThLarge size={40} />
</div>
<div className="icon-wrapper">
<FaFileAlt size={40} />
</div>
<div className="icon-wrapper">
<FaStar size={40} />
</div>
</div>
{/* Content Area */}
<div className="content-area">
{/* Search & Filters */}
<div className="search-filter-container" style={{ display: "flex", alignItems: "center", gap: "40px" }}>
{/* Search */}
<div style={{ position: "relative", width: "250px" }}>
<input
type="text"
placeholder="Search"
value={query}
onChange={(e) => setQuery(e.target.value)}
style={{
paddingLeft: "35px",
width: "100%",
height: "35px",
borderRadius: "5px",
border: "1px solid #ccc",
}}
/>
<FaSearch
style={{
position: "absolute",
left: "10px",
top: "50%",
transform: "translateY(-50%)",
color: "#888",
}}
/>
</div>
{/* Type Filter Dropdown */}
<Dropdown>
<Dropdown.Toggle className="filter-btn">
{filterType || "Type"}
</Dropdown.Toggle>
<Dropdown.Menu>
<Dropdown.Item onClick={() => setFilterType("")}>All</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterType("PDF")}>PDF</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterType("CSV")}>CSV</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterType("XLSX")}>XLSX</Dropdown.Item>
</Dropdown.Menu>
</Dropdown>
{/* Year Filter Dropdown */}
<Dropdown>
<Dropdown.Toggle className="filter-btn">
{filterYear || "Year"}
</Dropdown.Toggle>
<Dropdown.Menu>
<Dropdown.Item onClick={() => setFilterYear("")}>All</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterYear("2025")}>2025</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterYear("2024")}>2024</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterYear("2023")}>2023</Dropdown.Item>
<Dropdown.Item onClick={() => setFilterYear("2022")}>2022</Dropdown.Item>
</Dropdown.Menu>
</Dropdown>
{/* Other Buttons */}
<button className="filter-btn">Export ⬇</button>
<Button variant="outline-secondary">
<FaTrash />
</Button>
</div>
{/* Employee Table */}
<Table bordered hover className="employee-table">
<thead>
<tr>
<th>
<input
type="checkbox"
checked={isSelectAll}
onChange={handleSelectAll}
/>
</th>
<th>Title</th>
<th>Type</th>
<th>Date</th>
<th>Size</th>
<th>Download</th>
<th>Favourites</th>
<th>Preview</th>
</tr>
</thead>
<tbody>
{filteredData.map((i) => (
<tr key={i.id}>
<td>
<input
type="checkbox"
checked={selectedRows.includes(i.id)}
onChange={() => handleSelectRow(i.id)}
/>
</td>
<td>{i.title}</td>
<td>{i.type}</td>
<td>{i.date}</td>
<td>{i.size}</td>
<td>
<FaDownload style={{ color: "black", cursor: "pointer" }} />
</td>
<td>
<FaStar style={{ color: "gold", cursor: "pointer" }} />
</td>
<td>
<FaEye style={{ color: "red", cursor: "pointer" }} />
</td>
</tr>
))}
</tbody>
</Table>
</div>
</div>
</div>
);
}
export default Dash;