import "./App.css";
import "./index.css";
import Dash from "./components/Dash";
function App() {
return (
<div>
<Dash />
</div>
);
}
export default App;