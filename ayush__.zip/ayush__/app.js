import './App.css';
// import DashboardLayout from './components/DashboardLayout';
// import Dashboard from './components/Dashboard';
// import Dash from './components/Dash';
import Dash from './components/Dash';
import "./index.css";
 
 
function App() {
  return (
    <div >
      <Dash />
    </div>
  );
}
 
export default App;