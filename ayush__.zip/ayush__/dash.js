import React, { useState } from "react";
import { Form, Button, Dropdown, Navbar, Container, FormControl, Table } from "react-bootstrap";
import {
  FaUserPlus,
  FaTrash,
  FaSearch,
  FaBell,
  FaUser,
  FaSquare,
  FaFolder,
  FaUserMinus,
} from "react-icons/fa";
import "../components/Dash.css";
// import Groupicon from "./Groupicon";
import Permission from "./Permission";
 
const empData = [
  { id: 1, name: "Yash", group: "ABC" },
  { id: 2, name: "Ashwith", group: "ABC" },
  { id: 3, name: "Lavanaya", group: "BCD" },
  { id: 4, name: "Vaishnavi", group: "BCD" },
  { id: 5, name: "Barnisha", group: "EFG" },
  { id: 6, name: "Ayush", group: "EFG" },
  { id: 7, name: "Karthick", group: "EFG" },
];
 
//Select row functionality
function Dash() {
  const [selectedRows, setSelectedRows] = useState([]);
  const [emp, setEmp] = useState(empData);
  const [query, setQuery] = useState("");
  const [selectedGroup, setSelectedGroup] = useState("");
 
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedRows(emp.map((i) => i.id));
    } else {
      setSelectedRows([]);
    }
  };
 
  const handleSelectrow = (id) => {
    if (selectedRows.includes(id)) {
      setSelectedRows(selectedRows.filter((rowId) => rowId !== id));
    } else {
      setSelectedRows([...selectedRows, id]);
    }
  };
 
  const removeUser = (id) => {
    setEmp(emp.filter((i) => i.id !== id));
    setSelectedRows(selectedRows.filter((rowId) => rowId !== id));
  };
 
  const isSelectAll = selectedRows.length === emp.length;
 
  const uniqueGroups = [...new Set(emp.map((i) => i.group))];
 
  const filteredData = emp.filter(
    (i) =>
      i.name.toLowerCase().includes(query.toLowerCase()) &&
      (selectedGroup === "" || i.group === selectedGroup)
  );
 
  return (
    <div className="dashboard-container">
      {/* Navbar */}
      <Navbar className="navbar shadow-sm">
        <div className="navbar-container">
          <Navbar.Brand href="#">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/0/0c/Standard_Chartered_(2021).svg"
              alt="logo"
              height={40}
              className=" img me-3"
            />
          </Navbar.Brand>
          <div className="navbar-icons">
            <FaBell size={30} />
            <FaUser size={30} />
          </div>
        </div>
      </Navbar>
 
      {/* Main content */}
      <div className="main-content">
        {/* Sidebar */}
        <div className="sidebar">
          <div className="icon-wrrapper">
            <FaUserPlus size={40} />
          </div>
          <div className="icon-wrapper">
            <FaSquare size={40} />
          </div>
        </div>
 
        {/* Content Area */}
        <div className="content-area">
          {/* Search & Filters */}
          <div className="search-filter-container">
            <div style={{ position: "relative", width: "250px" }}>
              <input
                type="text"
                placeholder="Search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                style={{
                  paddingLeft: "35px",
                  width: "100%",
                  height: "35px",
                  borderRadius: "5px",
                  border: "1px solid #ccc",
                }}
              />
              <FaSearch
                style={{
                  position: "absolute",
                  left: "10px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "#888",
                }}
              />
            </div>
 
            {/* Group Dropdown */}
            <Dropdown className="group-dropdown">
              <Dropdown.Toggle variant="btn-primary">
                {selectedGroup === "" ? "All Groups" : selectedGroup}
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item onClick={() => setSelectedGroup("")}>
                  All Groups
                </Dropdown.Item>
                {uniqueGroups.map((g, idx) => (
                  <Dropdown.Item key={idx} onClick={() => setSelectedGroup(g)}>
                    {g}
                  </Dropdown.Item>
                ))}
              </Dropdown.Menu>
            </Dropdown>
 
            <Button
              variant="outline-secondary"
              onClick={() => {
                setEmp(emp.filter((i) => !selectedRows.includes(i.id)));
                setSelectedRows([]);
              }}
            >
              <FaTrash />
            </Button>
          </div>
 
          {/* Employee Table */}
          <Table bordered hover className="employee-table">
            <thead>
              <tr>
                <th>
                  <input
                    type="checkbox"
                    checked={isSelectAll}
                    onChange={handleSelectAll}
                  />
                </th>
                <th>Employee Id</th>
                <th>Name</th>
                <th>Group</th>
                <th>Profile</th>
                <th>Permission</th>
                <th>File</th>
                <th>Remove User</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map((i) => (
                <tr key={i.id}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedRows.includes(i.id)}
                      onChange={() => handleSelectrow(i.id)}
                    />
                  </td>
                  <td>{i.id}</td>
                  <td>{i.name}</td>
                  <td>{i.group}</td>
                  <td>
                    <FaUser style={{ color: "black" }} />
                  </td>
                  <td>
                    <Permission />
                  </td>
                  <td>
                    <FaFolder style={{ color: "gold" }} />
                  </td>
                  <td>
                    <FaUserMinus
                      style={{ color: "red", cursor: "pointer" }}
                      onClick={() => removeUser(i.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
    </div>
  );
}
 
export default Dash;